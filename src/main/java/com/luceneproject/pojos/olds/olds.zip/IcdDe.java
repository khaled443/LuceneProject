/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.luceneproject.pojos;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author kk
 */
@Entity
@Table(name = "icd_de")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "IcdDe.findAll", query = "SELECT i FROM IcdDe i")
    , @NamedQuery(name = "IcdDe.findById", query = "SELECT i FROM IcdDe i WHERE i.id = :id")
    , @NamedQuery(name = "IcdDe.findByCreationDate", query = "SELECT i FROM IcdDe i WHERE i.creationDate = :creationDate")
    , @NamedQuery(name = "IcdDe.findByModificationDate", query = "SELECT i FROM IcdDe i WHERE i.modificationDate = :modificationDate")
    , @NamedQuery(name = "IcdDe.findByCountryEn", query = "SELECT i FROM IcdDe i WHERE i.countryEn = :countryEn")
    , @NamedQuery(name = "IcdDe.findByIcdCode", query = "SELECT i FROM IcdDe i WHERE i.icdCode = :icdCode")
    , @NamedQuery(name = "IcdDe.findByIcdIsCompleteFl", query = "SELECT i FROM IcdDe i WHERE i.icdIsCompleteFl = :icdIsCompleteFl")
    , @NamedQuery(name = "IcdDe.findByIcdParentId", query = "SELECT i FROM IcdDe i WHERE i.icdParentId = :icdParentId")
    , @NamedQuery(name = "IcdDe.findByIcdYear", query = "SELECT i FROM IcdDe i WHERE i.icdYear = :icdYear")
    , @NamedQuery(name = "IcdDe.findByIcdDepth", query = "SELECT i FROM IcdDe i WHERE i.icdDepth = :icdDepth")
    , @NamedQuery(name = "IcdDe.findByIcdDescription", query = "SELECT i FROM IcdDe i WHERE i.icdDescription = :icdDescription")
    , @NamedQuery(name = "IcdDe.findByIcdExclusion", query = "SELECT i FROM IcdDe i WHERE i.icdExclusion = :icdExclusion")
    , @NamedQuery(name = "IcdDe.findByIcdInclusion", query = "SELECT i FROM IcdDe i WHERE i.icdInclusion = :icdInclusion")
    , @NamedQuery(name = "IcdDe.findByIcdNote", query = "SELECT i FROM IcdDe i WHERE i.icdNote = :icdNote")})
public class IcdDe implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Integer id;
    @Column(name = "CREATION_DATE")
    @Temporal(TemporalType.DATE)
    private Date creationDate;
    @Column(name = "MODIFICATION_DATE")
    @Temporal(TemporalType.DATE)
    private Date modificationDate;
    @Size(max = 25)
    @Column(name = "COUNTRY_EN")
    private String countryEn;
    @Size(max = 15)
    @Column(name = "ICD_CODE")
    private String icdCode;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ICD_IS_COMPLETE_FL")
    private int icdIsCompleteFl;
    @Column(name = "ICD_PARENT_ID")
    private BigInteger icdParentId;
    @Column(name = "ICD_YEAR")
    private Integer icdYear;
    @Column(name = "ICD_DEPTH")
    private Integer icdDepth;
    @Size(max = 2147483647)
    @Column(name = "ICD_DESCRIPTION")
    private String icdDescription;
    @Size(max = 2147483647)
    @Column(name = "ICD_EXCLUSION")
    private String icdExclusion;
    @Size(max = 2147483647)
    @Column(name = "ICD_INCLUSION")
    private String icdInclusion;
    @Size(max = 2147483647)
    @Column(name = "ICD_NOTE")
    private String icdNote;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "icdcCode")
    private Collection<TCaseIcd> tCaseIcdCollection;

    public IcdDe() {
    }

    public IcdDe(Integer id) {
        this.id = id;
    }

    public IcdDe(Integer id, int icdIsCompleteFl) {
        this.id = id;
        this.icdIsCompleteFl = icdIsCompleteFl;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Date getModificationDate() {
        return modificationDate;
    }

    public void setModificationDate(Date modificationDate) {
        this.modificationDate = modificationDate;
    }

    public String getCountryEn() {
        return countryEn;
    }

    public void setCountryEn(String countryEn) {
        this.countryEn = countryEn;
    }

    public String getIcdCode() {
        return icdCode;
    }

    public void setIcdCode(String icdCode) {
        this.icdCode = icdCode;
    }

    public int getIcdIsCompleteFl() {
        return icdIsCompleteFl;
    }

    public void setIcdIsCompleteFl(int icdIsCompleteFl) {
        this.icdIsCompleteFl = icdIsCompleteFl;
    }

    public BigInteger getIcdParentId() {
        return icdParentId;
    }

    public void setIcdParentId(BigInteger icdParentId) {
        this.icdParentId = icdParentId;
    }

    public Integer getIcdYear() {
        return icdYear;
    }

    public void setIcdYear(Integer icdYear) {
        this.icdYear = icdYear;
    }

    public Integer getIcdDepth() {
        return icdDepth;
    }

    public void setIcdDepth(Integer icdDepth) {
        this.icdDepth = icdDepth;
    }

    public String getIcdDescription() {
        return icdDescription;
    }

    public void setIcdDescription(String icdDescription) {
        this.icdDescription = icdDescription;
    }

    public String getIcdExclusion() {
        return icdExclusion;
    }

    public void setIcdExclusion(String icdExclusion) {
        this.icdExclusion = icdExclusion;
    }

    public String getIcdInclusion() {
        return icdInclusion;
    }

    public void setIcdInclusion(String icdInclusion) {
        this.icdInclusion = icdInclusion;
    }

    public String getIcdNote() {
        return icdNote;
    }

    public void setIcdNote(String icdNote) {
        this.icdNote = icdNote;
    }

    @XmlTransient
    public Collection<TCaseIcd> getTCaseIcdCollection() {
        return tCaseIcdCollection;
    }

    public void setTCaseIcdCollection(Collection<TCaseIcd> tCaseIcdCollection) {
        this.tCaseIcdCollection = tCaseIcdCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof IcdDe)) {
            return false;
        }
        IcdDe other = (IcdDe) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.luceneproject.pojos.IcdDe[ id=" + id + " ]";
    }
    
}
